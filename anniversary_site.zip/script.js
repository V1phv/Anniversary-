const button = document.getElementById('surpriseBtn');
const surprise = document.getElementById('surprise');

button.addEventListener('click', () => {
  surprise.classList.toggle('hidden');
});